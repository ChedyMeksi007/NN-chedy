#ifndef _MAIN_HPP_
#define _MAIN_HPP_

#include "neuron.hpp"
#include "matrix.hpp"
#include "layer.hpp"
#include "utils/math.hpp"

#endif
