import pandas as pd
import numpy as np

# Function to process a CSV file, extract labels, and convert labels to one-hot encoding in 10x1 format
def process_mnist_csv(file_path, output_data_path, output_labels_path):
    # Read the CSV file, skipping the first line
    df = pd.read_csv(file_path, skiprows=1, header=None)

    # Extract the labels (first column)
    labels = df.iloc[:, 0]

    # Remove the label column from the data
    data = df.iloc[:, 1:].astype(float)  # Convert all data to float

    # Initialize an empty list to store the one-hot encoded labels
    one_hot_labels_list = []

    # One-hot encode the labels and append to the list
    for label in labels:
        one_hot_label = np.zeros(10, dtype=float)  # Ensure labels are floats
        one_hot_label[label] = 1.0
        one_hot_labels_list.append(one_hot_label)

    # Convert the list of one-hot labels to a DataFrame
    one_hot_labels = pd.DataFrame(one_hot_labels_list)
    data = data/255

    # Save the processed data and one-hot encoded labels to new files
    data.to_csv(output_data_path, index=False, header=False, float_format='%.1f')
    one_hot_labels.to_csv(output_labels_path, index=False, header=False, float_format='%.1f')

# Process the training data
process_mnist_csv('mnist_train.csv', 'mnist_train_data.csv', 'mnist_train_labels.csv')

# Process the test data
process_mnist_csv('mnist_test.csv', 'mnist_test_data.csv', 'mnist_test_labels.csv')
